"""
utils/auth.py
--------------
Signup / login / session handling for the skill extractor app.

Uses SQLite (stdlib sqlite3 — no extra database server needed) and
hashlib.pbkdf2_hmac for password hashing (stdlib — avoids requiring
bcrypt/passlib as extra dependencies for a small internship project).
Sessions are simple random tokens stored in their own table and set as
an HttpOnly cookie — no JWT library needed either.
"""
from typing import Optional
import sqlite3
import hashlib
import secrets
from pathlib import Path
from datetime import datetime, timedelta

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "app.db"
SESSION_LIFETIME_HOURS = 24


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create the users and sessions tables if they don't exist yet.
    Safe to call every time the app starts."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = get_connection()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            token TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            expires_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    conn.commit()
    conn.close()


# ------------------------------------------------------------------
# Password hashing
# ------------------------------------------------------------------

def hash_password(password: str, salt: Optional[str] = None) -> tuple[str, str]:
    """Returns (hash, salt). Generates a new random salt if none is given."""
    if salt is None:
        salt = secrets.token_hex(16)
    pw_hash = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"), 100_000
    ).hex()
    return pw_hash, salt


def verify_password(password: str, stored_hash: str, salt: str) -> bool:
    candidate_hash, _ = hash_password(password, salt)
    return secrets.compare_digest(candidate_hash, stored_hash)


# ------------------------------------------------------------------
# User management
# ------------------------------------------------------------------

def create_user(username: str, email: str, password: str) -> dict:
    """Returns {'success': True, 'user_id': ...} or {'success': False, 'error': ...}."""
    conn = get_connection()
    try:
        existing = conn.execute(
            "SELECT id FROM users WHERE username = ? OR email = ?", (username, email)
        ).fetchone()
        if existing:
            return {"success": False, "error": "Username or email already registered."}

        pw_hash, salt = hash_password(password)
        cursor = conn.execute(
            "INSERT INTO users (username, email, password_hash, salt, created_at) VALUES (?, ?, ?, ?, ?)",
            (username, email, pw_hash, salt, datetime.utcnow().isoformat()),
        )
        conn.commit()
        return {"success": True, "user_id": cursor.lastrowid}
    finally:
        conn.close()


def authenticate_user(username: str, password: str) -> Optional[dict]:
    """Returns the user row (as dict) if credentials are valid, else None."""
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM users WHERE username = ?", (username,)
        ).fetchone()
        if row is None:
            return None
        if not verify_password(password, row["password_hash"], row["salt"]):
            return None
        return dict(row)
    finally:
        conn.close()


# ------------------------------------------------------------------
# Sessions
# ------------------------------------------------------------------

def create_session(user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    expires_at = (datetime.utcnow() + timedelta(hours=SESSION_LIFETIME_HOURS)).isoformat()
    conn = get_connection()
    try:
        conn.execute(
            "INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)",
            (token, user_id, expires_at),
        )
        conn.commit()
        return token
    finally:
        conn.close()


def get_user_from_token(token: str) -> Optional[dict]:
    if not token:
        return None
    conn = get_connection()
    try:
        row = conn.execute(
            """
            SELECT users.* FROM sessions
            JOIN users ON users.id = sessions.user_id
            WHERE sessions.token = ? AND sessions.expires_at > ?
            """,
            (token, datetime.utcnow().isoformat()),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def delete_session(token: str):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
        conn.commit()
    finally:
        conn.close()
