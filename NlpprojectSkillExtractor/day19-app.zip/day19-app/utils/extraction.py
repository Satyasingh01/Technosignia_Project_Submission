"""
utils/extraction.py
--------------------
Skill extraction logic: taxonomy regex matching, spaCy PhraseMatcher, and the
union ensemble of the two (the combination that scored highest in evaluation —
see Day 15/16 documentation). Kept separate from app.py so the extraction logic
can be tested, reused, or swapped independently of the API layer.
"""
from typing import Optional
import re
import pickle
from pathlib import Path

import spacy
from spacy.matcher import PhraseMatcher

MODEL_PATH = Path(__file__).resolve().parent.parent / "model" / "taxonomy.pkl"


def load_taxonomy(path: Path = MODEL_PATH):
    """Load the pickled taxonomy artifact: {skill_taxonomy, synonym_to_skill}."""
    with open(path, "rb") as f:
        return pickle.load(f)


class SkillExtractor:
    """
    Loads the taxonomy and builds both matchers ONCE (at construction time),
    not per request. Instantiate a single SkillExtractor at app startup and
    reuse it for every incoming request.
    """

    def __init__(self, taxonomy_path: Path = MODEL_PATH):
        tax = load_taxonomy(taxonomy_path)
        self.skill_taxonomy = tax["skill_taxonomy"]        # {category: {canonical_skill: [synonyms]}}
        self.synonym_to_skill = tax["synonym_to_skill"]    # {synonym: {"canonical_skill":.., "category":..}}

        self._compiled_patterns = [
            (re.compile(r"\b" + re.escape(syn) + r"\b"), info)
            for syn, info in self.synonym_to_skill.items()
        ]

        self.nlp = spacy.load("en_core_web_sm")
        self.matcher = PhraseMatcher(self.nlp.vocab, attr="LOWER")
        for syn, info in self.synonym_to_skill.items():
            self.matcher.add(info["canonical_skill"], [self.nlp.make_doc(syn)])

    # ------------------------------------------------------------
    # Preprocessing
    # ------------------------------------------------------------
    @staticmethod
    def preprocess(text: str) -> str:
        """Basic normalization before matching."""
        return text.strip()

    # ------------------------------------------------------------
    # Skill Extraction Model (Method 1 — Taxonomy regex)
    # ------------------------------------------------------------
    def extract_taxonomy_skills(self, text: str) -> dict:
        text_lower = text.lower()
        found = {}
        for pattern, info in self._compiled_patterns:
            if pattern.search(text_lower):
                found[info["canonical_skill"]] = info["category"]
        return found

    # ------------------------------------------------------------
    # Skill Extraction Model (Method 2 — spaCy PhraseMatcher)
    # ------------------------------------------------------------
    def extract_spacy_skills(self, text: str) -> dict:
        doc = self.nlp(text)
        matches = self.matcher(doc)
        found = {}
        for match_id, start, end in matches:
            canonical = self.nlp.vocab.strings[match_id]
            category = next(
                (info["category"] for info in self.synonym_to_skill.values()
                 if info["canonical_skill"] == canonical),
                "Unknown",
            )
            found[canonical] = category
        return found

    # ------------------------------------------------------------
    # Skill Normalization + Category Mapping + Final Skills
    # ------------------------------------------------------------
    def extract(self, text: str) -> list[dict]:
        """
        Full pipeline: preprocess -> extract (both methods) -> normalize
        (dedupe canonical names) -> map category -> return final skill list.
        """
        clean_text = self.preprocess(text)

        combined = {}
        combined.update(self.extract_taxonomy_skills(clean_text))
        combined.update(self.extract_spacy_skills(clean_text))

        return [
            {"canonical_skill": skill, "category": category}
            for skill, category in sorted(combined.items())
        ]

    # ------------------------------------------------------------
    # Recommended Technology
    # ------------------------------------------------------------
    TECH_CATEGORIES = {"Programming", "Database", "Cloud", "Business Intelligence",
                        "Data Engineering", "DevOps", "Machine Learning"}

    def recommended_technology(self, skills: list[dict]) -> Optional[str]:
        """Returns the first detected skill that falls in a technical category,
        used as a simple 'most relevant technology' signal for the response."""
        for s in skills:
            if s["category"] in self.TECH_CATEGORIES:
                return s["canonical_skill"]
        return skills[0]["canonical_skill"] if skills else None
