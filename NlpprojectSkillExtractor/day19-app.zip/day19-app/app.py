"""
app.py
------
Day 19 deliverable — the application entrypoint, now with account-based access:
users sign up, log in, and only then can call the extraction endpoint.

Architecture:

    User
      |
    Web Interface        (frontend/welcome.html -> login.html/signup.html -> index.html)
      |
    Auth                  utils.auth: signup, login (SQLite + hashed passwords + session cookie)
      |
    Preprocessing         utils.extraction.SkillExtractor.preprocess
      |
    Skill Extraction Model utils.extraction.SkillExtractor.extract_taxonomy_skills
      |                    + extract_spacy_skills (union ensemble)
      |
    Skill Normalization    deduplication by canonical_skill name
      |
    Category Mapping       canonical_skill -> taxonomy category
      |
    Final Skills           returned as JSON (only to logged-in users)

Run:
    pip install -r requirements.txt
    python -m spacy download en_core_web_sm
    uvicorn app:app --reload --port 8000
    http://localhost:5500/welcome.html
"""
from typing import Optional
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr

from utils import (
    SkillExtractor,
    init_db,
    create_user,
    authenticate_user,
    create_session,
    get_user_from_token,
    delete_session,
)

# ------------------------------------------------------------------
# Load the model + database ONCE at startup — not per request
# ------------------------------------------------------------------
extractor = SkillExtractor()
init_db()

app = FastAPI(
    title="Job Skill Extraction API",
    description="Sign up, log in, paste a job description, get back detected skills grouped by category.",
    version="2.0.0",
)

# allow_credentials=True is required for the session cookie to work, which means
# allow_origins can't be "*" (the browser will reject that combination) — instead
# any localhost/127.0.0.1 origin is allowed, covering any port your dev server uses.
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"http://(localhost|127\.0\.0\.1):\d+",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SESSION_COOKIE_NAME = "session_token"


def get_current_user(request: Request) -> dict:
    token = request.cookies.get(SESSION_COOKIE_NAME)
    user = get_user_from_token(token)
    if user is None:
        raise HTTPException(status_code=401, detail="Not logged in. Please log in first.")
    return user


# ------------------------------------------------------------------
# Auth models
# ------------------------------------------------------------------

class SignupRequest(BaseModel):
    username: str
    email: EmailStr
    password: str


class LoginRequest(BaseModel):
    username: str
    password: str


class UserPublic(BaseModel):
    username: str
    email: str


# ------------------------------------------------------------------
# Auth endpoints
# ------------------------------------------------------------------

@app.post("/signup")
def signup(payload: SignupRequest):
    if len(payload.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters.")

    result = create_user(payload.username, payload.email, payload.password)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["error"])

    return {"message": "Account created successfully. Please log in."}


@app.post("/login")
def login(payload: LoginRequest, response: Response):
    user = authenticate_user(payload.username, payload.password)
    if user is None:
        raise HTTPException(status_code=401, detail="Invalid username or password.")

    token = create_session(user["id"])
    response.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=token,
        httponly=True,
        samesite="lax",
        max_age=60 * 60 * 24,  # 24 hours, matches SESSION_LIFETIME_HOURS in utils/auth.py
    )
    return {"message": f"Welcome back, {user['username']}!", "username": user["username"]}


@app.post("/logout")
def logout(request: Request, response: Response):
    token = request.cookies.get(SESSION_COOKIE_NAME)
    if token:
        delete_session(token)
    response.delete_cookie(SESSION_COOKIE_NAME)
    return {"message": "Logged out."}


@app.get("/me", response_model=UserPublic)
def me(request: Request):
    user = get_current_user(request)
    return {"username": user["username"], "email": user["email"]}


# ------------------------------------------------------------------
# Extraction models
# ------------------------------------------------------------------

class ExtractRequest(BaseModel):
    job_description: str


class SkillResult(BaseModel):
    canonical_skill: str
    category: str


class ExtractResponse(BaseModel):
    skills: list[SkillResult]
    skill_count: int
    recommended_technology: Optional[str]


@app.post("/extract-skills", response_model=ExtractResponse)
def extract_skills(payload: ExtractRequest, request: Request):
    get_current_user(request)  # raises 401 if not logged in

    skills = extractor.extract(payload.job_description)
    return {
        "skills": skills,
        "skill_count": len(skills),
        "recommended_technology": extractor.recommended_technology(skills),
    }


@app.get("/health")
def health():
    return {"status": "ok", "taxonomy_skills_loaded": len(extractor.synonym_to_skill)}


@app.get("/")
def root():
    return {
        "message": "Job Skill Extraction API is running.",
        "docs": "/docs",
        "endpoints": ["POST /signup", "POST /login", "POST /logout", "GET /me", "POST /extract-skills"],
    }
